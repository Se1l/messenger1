import tkinter as tk
from tkinter import ttk
from tkinter import messagebox, simpledialog
import sqlite3
import hashlib
from datetime import datetime

class Database:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.c = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.c.execute('''CREATE TABLE IF NOT EXISTS users
                         (id INTEGER PRIMARY KEY, username TEXT, password TEXT)''')

        self.c.execute('''CREATE TABLE IF NOT EXISTS messages
                         (id INTEGER PRIMARY KEY, sender TEXT, recipient TEXT, message TEXT, timestamp DATETIME)''')

        self.conn.commit()

    def register_user(self, username, password):
        hashed_password = self.hash_password(password)
        self.c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        self.conn.commit()

    def verify_user(self, username, password):
        hashed_password = self.hash_password(password)
        self.c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed_password))
        return self.c.fetchone() is not None

    def change_password(self, username, new_password):
        hashed_password = self.hash_password(new_password)
        self.c.execute("UPDATE users SET password=? WHERE username=?", (hashed_password, username))
        self.conn.commit()

    def get_usernames(self):
        self.c.execute("SELECT username FROM users")
        return [row[0] for row in self.c.fetchall()]

    def add_message(self, sender, recipient, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.c.execute("INSERT INTO messages (sender, recipient, message, timestamp) VALUES (?, ?, ?, ?)",
                       (sender, recipient, message, timestamp))
        self.conn.commit()

    def get_messages(self, sender, recipient):
        self.c.execute("SELECT * FROM messages WHERE (sender=? AND recipient=?) OR (sender=? AND recipient=?) ORDER BY timestamp",
                       (sender, recipient, recipient, sender))
        return self.c.fetchall()

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def close_connection(self):
        self.conn.close()

class Application:
    def __init__(self, master):
        self.master = master
        self.master.title("Messenger")
        self.master.geometry("500x500")  
        self.db = Database('example.db')

        self.logged_in = False
        self.current_user = None

        self.username_label = tk.Label(master, text="Username:")
        self.username_label.pack()
        self.username_entry = tk.Entry(master)
        self.username_entry.pack()

        self.password_label = tk.Label(master, text="Password:")
        self.password_label.pack()
        self.password_entry = tk.Entry(master, show="*")
        self.password_entry.pack()

        self.register_button = tk.Button(master, text="Register", command=self.register)
        self.register_button.pack()

        self.login_button = tk.Button(master, text="Login", command=self.login)
        self.login_button.pack()

        self.tab_control = tk.ttk.Notebook(master)
        self.tab_control.pack(expand=True, fill="both")

        self.tabs = {}

        self.logout_button = tk.Button(master, text="Logout", command=self.logout)
        self.logout_button.pack()

    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if username and password:
            self.db.register_user(username, password)
            messagebox.showinfo("Success", "Registration successful")
        else:
            messagebox.showerror("Error", "Username and password cannot be empty")

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if username and password:
            if self.db.verify_user(username, password):
                messagebox.showinfo("Success", "Login successful")
                self.logged_in = True
                self.current_user = username
                self.show_logged_in_options()
            else:
                messagebox.showerror("Error", "Invalid username or password")
        else:
            messagebox.showerror("Error", "Username and password cannot be empty")

    def show_logged_in_options(self):
        self.username_label.pack_forget()
        self.username_entry.pack_forget()
        self.password_label.pack_forget()
        self.password_entry.pack_forget()
        self.register_button.pack_forget()
        self.login_button.pack_forget()

        self.profile_button = tk.Button(self.master, text="View Profile", command=self.view_profile)
        self.profile_button.pack()

        self.recipient_label = tk.Label(self.master, text="Select Recipient:")
        self.recipient_label.pack()

        self.recipient_var = tk.StringVar(self.master)
        self.recipient_var.set("Select...")
        self.recipient_menu = tk.OptionMenu(self.master, self.recipient_var, *self.db.get_usernames(),
                                            command=self.on_recipient_selected)
        self.recipient_menu.pack()

        self.message_label = tk.Label(self.master, text="Enter Message:")
        self.message_label.pack()

        self.message_entry = tk.Entry(self.master)
        self.message_entry.pack()

        self.send_button = tk.Button(self.master, text="Send", command=self.send_message)
        self.send_button.pack()

    def on_recipient_selected(self, event):
        recipient = self.recipient_var.get()
        if recipient != "Select...":
            self.create_or_update_chat_tab(recipient)

    def view_profile(self):
        messagebox.showinfo("Profile", f"Logged in as: {self.current_user}")

    def send_message(self):
        recipient = self.recipient_var.get()
        message = self.message_entry.get()
        if recipient != "Select..." and message:
            messagebox.showinfo("Message Sent", f"Message sent to {recipient}: {message}")
            self.db.add_message(self.current_user, recipient, message)
            self.message_entry.delete(0, tk.END)
            self.create_or_update_chat_tab(recipient)
        else:
            messagebox.showerror("Error", "Recipient and message cannot be empty")

    def create_or_update_chat_tab(self, recipient):
        if recipient not in self.tabs:
            self.create_chat_tab(recipient)
        else:
            self.update_chat_tab(recipient)

    def create_chat_tab(self, recipient):
        chat_frame = tk.Frame(self.tab_control)
        self.tabs[recipient] = chat_frame
        self.tab_control.add(chat_frame, text=recipient)

        chat_log_label = tk.Label(chat_frame, text="Chat Log:")
        chat_log_label.pack()

        chat_log = tk.Text(chat_frame, height=15, width=60)
        chat_log.pack()

        self.load_messages(chat_log, recipient)

    def load_messages(self, chat_log, recipient):
        messages = self.db.get_messages(self.current_user, recipient)
        for message in messages:
            try:
                _, sender, _, msg, timestamp = message
                chat_log.insert(tk.END, f"{timestamp} {sender}: {msg}\n")
            except ValueError as e:
                print(f"Error parsing message: {e}")
                print(f"Received message: {message}")

    def update_chat_tab(self, recipient):
        chat_frame = self.tabs[recipient]
        chat_log = chat_frame.winfo_children()[1]
        chat_log.delete(1.0, tk.END)

        messages = self.db.get_messages(self.current_user, recipient)
        for message in messages:
            try:
                _, sender, _, msg, timestamp = message
                chat_log.insert(tk.END, f"{timestamp} {sender}: {msg}\n")
            except ValueError as e:
                print(f"Error parsing message: {e}")
                print(f"Received message: {message}")

    def logout(self):
        self.logged_in = False
        self.current_user = None
        self.profile_button.pack_forget()
        self.recipient_label.pack_forget()
        self.recipient_menu.pack_forget()
        self.message_label.pack_forget()
        self.message_entry.pack_forget()
        self.send_button.pack_forget()
        self.username_label.pack()
        self.username_entry.pack()
        self.password_label.pack()
        self.password_entry.pack()
        self.register_button.pack()
        self.login_button.pack()
        self.tab_control.destroy()
        self.tab_control = tk.ttk.Notebook(self.master)
        self.tab_control.pack(expand=True, fill="both")
        self.tabs = {}

    def __del__(self):
        self.db.close_connection()

if __name__ == "__main__":
    root = tk.Tk()
    app = Application(root)
    root.mainloop()
